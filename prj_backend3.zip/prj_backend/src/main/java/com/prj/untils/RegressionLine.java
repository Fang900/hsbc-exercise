package com.prj.untils;

import com.prj.dto.SalaryData;
import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Data
public class RegressionLine {

    private float sumX = 0;//训练集x的和
    private float sumY = 0;//训练集y的和
    private float sumXX = 0;//x*x的和
    private float sumYY = 0;//y*y的和
    private float sumXY = 0;//x*y的和
    private float sumDeltaY2; // sumDeltaY的平方和

    private ArrayList<Float> listX;//x的链表
    private ArrayList<Float> listY;//y的链表
    private float a0;//线性系数a0
    private float a1;//线性系数a1
    private int pn;  //训练集数据个数
    private double mse;

    //类RegressionLine的构造函数
    public RegressionLine() {
        this(Collections.emptyList());
    }

    //类RegressionLine的有参构造函数
    public RegressionLine(List<SalaryData> data) {
        pn = 0;
        listX = new ArrayList();
        listY = new ArrayList();
        data.forEach(d -> addDatapoint(d));
        validateCoefficients();
        this.mse = this.calMSE();
    }

    public void addDatapoint(SalaryData dataPoint) {
        sumX += dataPoint.getYears();
        sumY += dataPoint.getSalary();
        sumXX += dataPoint.getYears() * dataPoint.getYears();
        sumYY += dataPoint.getSalary() * dataPoint.getSalary();
        sumXY += dataPoint.getYears() * dataPoint.getSalary();
        listX.add(pn, dataPoint.getYears());
        listY.add(pn, dataPoint.getSalary());
        ++pn;
    }

    //计算系数a0，a1的方法
    private void validateCoefficients() {
        if (pn >= 2) {
            float xBar = (float) sumX / pn;
            float yBar = (float) sumY / pn;
            a1 = (float) ((pn * sumXY - sumX * sumY) / (pn
                    * sumXX - sumX * sumX));
            a0 = (yBar - a1 * xBar);
        } else {
            a0 = a1 = Float.NaN;
        }
    }

    //计算判定系数MSE的方法
    public double calMSE() {
        for (int i = 0; i < pn; i++) {
            float deltaY = listY.get(i) - (listX.get(i) * a1 + a0);
            float deltaY2 = deltaY * deltaY;
            sumDeltaY2 += deltaY2;
        }
        return sumDeltaY2 / pn;
    }
}