package com.prj.untils;

import com.prj.dto.SalaryData;
import lombok.Data;
import lombok.val;

import java.util.List;

@Data
public class SalaryDataPrediction {
    SalaryData salaryData;

    String regressionLine;

    String mse;

    public SalaryDataPrediction(float years, List<SalaryData> salaryData) {
        val regressionLine = new RegressionLine(salaryData);
        mse = String.valueOf(regressionLine.getMse());
        val data = new SalaryData();
        data.setYears(years);
        data.setSalary(years != 0 ? regressionLine.getA1() * years + regressionLine.getA0() : 0);
        this.salaryData = data;

        this.regressionLine = "\n回归线公式：y = " + regressionLine.getA1()
                + "x + " + regressionLine.getA0();

    }
}
