package com.prj.dto;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

@Entity
@Data
public class Dept {
    @Id
    @NotBlank(message = "id为必传参数")
    private String id;
    private String manager;
    private String name;
}
