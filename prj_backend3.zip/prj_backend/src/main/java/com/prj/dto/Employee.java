package com.prj.dto;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class Employee {
    @Id
    private String id;
    @ManyToOne
    private Dept dept;
    private String name;
    private String position;
    private Float salary;

    public Employee addSalary(float salary) {
        this.salary += salary;
        return this;
    }
}
