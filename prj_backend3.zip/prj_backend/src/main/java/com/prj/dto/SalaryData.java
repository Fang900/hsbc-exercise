package com.prj.dto;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class SalaryData {
    @Id
    private float years;
    private float salary;
}
