package com.prj.dto;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Data
public class EmployeeKpi {

    @Id
    private String id;
    @ManyToOne
    @JoinColumn(name = "employeeID", insertable = true, updatable = false)
    private Employee employee;
    private String leader;
    private String comments;
    private String kpi;
    private LocalDate checkDate = LocalDate.now();
}
