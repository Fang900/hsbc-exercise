package com.prj.dto;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Data
public class SalaryApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int applicationId;
    @Column(name = "employee_id")
    private String employeeId;
    private String comment;
    private LocalDate date = LocalDate.now();
    private float salaryChange;
}
