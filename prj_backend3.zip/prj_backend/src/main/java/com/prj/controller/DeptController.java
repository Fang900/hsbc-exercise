package com.prj.controller;

import com.prj.dto.Dept;
import com.prj.serivce.DeptService;
import lombok.RequiredArgsConstructor;
import lombok.val;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/dept")
@RequiredArgsConstructor
public class DeptController {

    final DeptService deptService;

    final static String BASE_VIEW = "dept/dept";
    final static String BASE_SAVE_VIEW = "dept/deptsave";

    @RequestMapping("/find")
    public String findAll(Model model, @RequestParam(defaultValue = "0") int page) {
        val depts = deptService.findAll(PageRequest.of(page > 0 ? page - 1 : 0, 5));
        model.addAttribute("data", depts);
        return BASE_VIEW;
    }

    @RequestMapping("/update/{id}")
    public String saveView(Model model, @PathVariable("id") Dept dept) {
        model.addAttribute("dept", dept);
        return BASE_SAVE_VIEW;
    }

    @PostMapping("/save")
    public String save(Model model, @Validated Dept dept) {
        deptService.savaDept(dept);
        return findAll(model, 0);
    }

    @RequestMapping("/delete/{id}")
    public String delete(@PathVariable String id) {
        deptService.deleteById(id);
        return "redirect:/"+BASE_VIEW;
    }
}
