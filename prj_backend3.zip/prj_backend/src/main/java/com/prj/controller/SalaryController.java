package com.prj.controller;


import com.prj.dto.Employee;
import com.prj.dto.SalaryApplication;
import com.prj.serivce.DeptService;
import com.prj.serivce.EmployeeService;
import com.prj.serivce.SalaryService;
import lombok.RequiredArgsConstructor;
import lombok.val;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/salary")
@RequiredArgsConstructor
public class SalaryController {

    final String SALARY_VIEW = "employee/salary";
    final String SALARY_PREDICTION_VIEW = "salaryPrediction";

    final EmployeeService employeeService;

    final SalaryService salaryService;

    final DeptService deptService;

    @RequestMapping("/find")
    public String findAll(Model model, @RequestParam(defaultValue = "0") int page) {
        val employees = employeeService.findAll(PageRequest.of(page > 0 ? page - 1 : 0, 5));
        model.addAttribute("data", employees);
        return SALARY_VIEW;
    }

    @RequestMapping("/search")
    public String search(Model model, Employee employee, Pageable pageable) {
        val employees = employeeService.findAll(employee, pageable);
        model.addAttribute("data", employees);
        model.addAttribute("search", employee);
        return SALARY_VIEW;
    }


    @RequestMapping("/update/{id}")
    public String updateView(Model model, @PathVariable("id") Employee employee) {
        model.addAttribute("data", employee);
        return SALARY_VIEW;
    }


    @PostMapping("/save")
    public String save(Model model, @RequestParam("id") Employee employee, SalaryApplication salaryApplication) {
        employeeService.save(employee.addSalary(salaryApplication.getSalaryChange()));
        salaryService.save(salaryApplication);
        return "redirect:/employee/find";
    }

    @RequestMapping("/prediction")
    public String salaryPrediction(Model model, @RequestParam(defaultValue = "0") final int years) {
        model.addAttribute("data", salaryService.getPrediction(years));
        return SALARY_PREDICTION_VIEW;
    }
}
