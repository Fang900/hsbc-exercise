package com.prj.controller;


import lombok.val;
import org.springframework.http.HttpRequest;
import org.springframework.http.server.RequestPath;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class CommonController {

    @RequestMapping("/fd/**")
    public String forword(HttpServletRequest request){
        return request.getRequestURI().substring(3);
    }
}
