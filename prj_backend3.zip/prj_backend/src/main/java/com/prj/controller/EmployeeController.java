package com.prj.controller;


import com.prj.dto.Employee;
import com.prj.serivce.DeptService;
import com.prj.serivce.EmployeeService;
import lombok.RequiredArgsConstructor;
import lombok.val;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/employee")
@RequiredArgsConstructor
public class EmployeeController {

    final String EMPLOYEE_VIEW = "employee/employee";
    final String EMPLOYEE_SAVE_VIEW = "employee/employeeSave";

    final EmployeeService employeeService;


    final DeptService deptService;

    @RequestMapping("/find")
    public String findAll(Model model, @RequestParam(defaultValue = "0") int page) {
        val employees = employeeService.findAll(PageRequest.of(page > 0 ? page - 1 : 0, 5));
        model.addAttribute("data", employees);
        return EMPLOYEE_VIEW;
    }

    @RequestMapping("/search")
    public String search(Model model, Employee employee, Pageable pageable) {
        val employees = employeeService.findAll(employee, pageable);
        model.addAttribute("data", employees);
        model.addAttribute("search", employee);
        return EMPLOYEE_VIEW;
    }


    @RequestMapping("/update/{id}")
    public String update(Model model, @PathVariable("id") Employee employee) {
        model.addAttribute("data", employee);
        return EMPLOYEE_SAVE_VIEW;
    }

    @RequestMapping("/update")
    public String update(Model model) {
        model.addAttribute("deptList", deptService.findAll(Pageable.unpaged()));
        return EMPLOYEE_SAVE_VIEW;
    }

    @PostMapping("/save")
    public String save(Model model, @Validated Employee employee) {
        employeeService.save(employee);
        return findAll(model, 0);
    }

    @RequestMapping("/delete/{id}")
    public String delete(@PathVariable String id) {
        employeeService.deleteById(id);
        return "redirect:/employee/find";
    }
}
