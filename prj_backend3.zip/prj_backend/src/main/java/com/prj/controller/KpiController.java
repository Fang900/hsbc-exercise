package com.prj.controller;


import com.prj.dto.Employee;
import com.prj.dto.EmployeeKpi;
import com.prj.serivce.DeptService;
import com.prj.serivce.EmployeeService;
import com.prj.serivce.KpiService;
import lombok.RequiredArgsConstructor;
import lombok.val;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.transaction.Transactional;

@Controller
@RequestMapping("/kpi")
@RequiredArgsConstructor
@Transactional(rollbackOn = Throwable.class)
public class KpiController {

    final String BASE_VIEW = "kpi/kpi";
    final String BASE_SAVE_VIEW = "kpi/kpiSave";

    final EmployeeService employeeService;


    final KpiService kpiService;

    @RequestMapping("/find")
    public String findAll(Model model, @RequestParam(defaultValue = "0") int page) {
        val employees = kpiService.findAll(PageRequest.of(page > 0 ? page - 1 : 0, 5));
        model.addAttribute("data", employees);
        return BASE_VIEW;
    }

    @RequestMapping("/search")
    public String search(Model model, EmployeeKpi kpi, Pageable pageable) {
        val employees = kpiService.findAll(kpi, pageable);
        model.addAttribute("data", employees);
        model.addAttribute("search", kpi);
        return BASE_VIEW;
    }


    @RequestMapping("/update/{id}")
    public String updateView(Model model, @PathVariable("id") Employee employee) {
        model.addAttribute("data", employee);
        return BASE_SAVE_VIEW;
    }


    @PostMapping("/save")
    public String save(Model model, EmployeeKpi kpi) {
        kpiService.save(kpi);
        return findAll(model, 0);
    }

    @RequestMapping("/delete/{id}")
    public String delete(@PathVariable String id) {
        kpiService.deleteById(id);
        return "redirect:/" + BASE_VIEW;
    }
}
