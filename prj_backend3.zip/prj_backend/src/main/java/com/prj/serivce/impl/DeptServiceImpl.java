package com.prj.serivce.impl;

import com.prj.dto.Dept;
import com.prj.repository.DeptRepository;
import com.prj.serivce.DeptService;
import lombok.RequiredArgsConstructor;
import lombok.val;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional(rollbackOn = Throwable.class)
@RequiredArgsConstructor
public class DeptServiceImpl implements DeptService {

    final DeptRepository deptRepository;

    public Page<Dept> findAll(Pageable pageable) {
        return deptRepository.findAll(pageable);
    }


    public Dept savaDept(Dept dept){
        return deptRepository.save(dept);
    }

    public void deleteById(String id){
        deptRepository.deleteById(id);
    }
}
