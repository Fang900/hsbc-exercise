package com.prj.serivce.impl;

import com.prj.dto.Dept;
import com.prj.dto.Employee;
import com.prj.repository.DeptRepository;
import com.prj.repository.EmployeeRepository;
import com.prj.serivce.DeptService;
import com.prj.serivce.EmployeeService;
import lombok.RequiredArgsConstructor;
import lombok.val;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional(rollbackOn = Throwable.class)
@RequiredArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    final EmployeeRepository employeeRepository;

    public Page<Employee> findAll(Pageable pageable) {
        return employeeRepository.findAll(pageable);
    }
    public Page<Employee> findAll(Employee employee, Pageable pageable) {

        val exampleMatcher = ExampleMatcher.matchingAll()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING);
        val example = Example.of(employee,exampleMatcher);
        return employeeRepository.findAll(example,pageable);
      }

    public Employee save(Employee employee){
        return employeeRepository.save(employee);
    }

    public void deleteById(String id){
        employeeRepository.deleteById(id);
    }
}
