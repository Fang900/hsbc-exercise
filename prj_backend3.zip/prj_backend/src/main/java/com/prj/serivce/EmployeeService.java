package com.prj.serivce;

import com.prj.dto.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface EmployeeService {

    Page<Employee> findAll(Employee employee, Pageable pageable);
    Page<Employee> findAll(Pageable pageable);

    public Employee save(Employee employee);

    public void deleteById(String id);
}
