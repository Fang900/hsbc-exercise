package com.prj.serivce;

import com.prj.dto.Employee;
import com.prj.dto.EmployeeKpi;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface KpiService {

    Page<EmployeeKpi> findAll(EmployeeKpi kpi, Pageable pageable);
    Page<EmployeeKpi> findAll(Pageable pageable);

    public EmployeeKpi save(EmployeeKpi kpi);

    public void deleteById(String id);
}
