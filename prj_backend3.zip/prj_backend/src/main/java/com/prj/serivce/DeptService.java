package com.prj.serivce;

import com.prj.dto.Dept;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface DeptService {

    Page<Dept> findAll(Pageable pageable);

    public Dept savaDept(Dept dept);

    public void deleteById(String id);
}
