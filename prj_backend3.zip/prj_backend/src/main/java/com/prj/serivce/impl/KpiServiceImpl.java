package com.prj.serivce.impl;

import com.prj.dto.Employee;
import com.prj.dto.EmployeeKpi;
import com.prj.repository.EmployeeRepository;
import com.prj.repository.KpiRepository;
import com.prj.serivce.EmployeeService;
import com.prj.serivce.KpiService;
import lombok.RequiredArgsConstructor;
import lombok.val;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional(rollbackOn = Throwable.class)
@RequiredArgsConstructor
public class KpiServiceImpl implements KpiService {

    final KpiRepository kpiRepository;

    public Page<EmployeeKpi> findAll(Pageable pageable) {
        return kpiRepository.findAll(pageable);
    }

    public Page<EmployeeKpi> findAll(EmployeeKpi kpi, Pageable pageable) {
        val exampleMatcher = ExampleMatcher.matchingAll()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING);
        val example = Example.of(kpi, exampleMatcher);
        return kpiRepository.findAll(example, pageable);
    }

    public EmployeeKpi save(EmployeeKpi kpi) {
        return kpiRepository.save(kpi);
    }

    public void deleteById(String id) {
        kpiRepository.deleteById(id);
    }
}
