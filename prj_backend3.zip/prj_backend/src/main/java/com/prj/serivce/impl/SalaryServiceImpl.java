package com.prj.serivce.impl;

import com.prj.dto.SalaryApplication;
import com.prj.repository.SalaryApplicationRepository;
import com.prj.repository.SalaryRepository;
import com.prj.serivce.SalaryService;
import com.prj.untils.SalaryDataPrediction;
import lombok.RequiredArgsConstructor;
import lombok.val;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional(rollbackOn = Throwable.class)
@RequiredArgsConstructor
public class SalaryServiceImpl implements SalaryService {

    final SalaryApplicationRepository salaryApplicationRepository;

    final SalaryRepository salaryRepository;

    public Page<SalaryApplication> findAll(Pageable pageable) {
        return salaryApplicationRepository.findAll(pageable);
    }
    public Page<SalaryApplication> findAll(SalaryApplication employee, Pageable pageable) {
        val exampleMatcher = ExampleMatcher.matchingAll()
                .withMatcher("id", ExampleMatcher.GenericPropertyMatcher::contains)
                .withMatcher("dept.name", ExampleMatcher.GenericPropertyMatcher::contains)
                .withMatcher("name", ExampleMatcher.GenericPropertyMatcher::contains)
                .withMatcher("position", ExampleMatcher.GenericPropertyMatcher::contains)
                .withMatcher("salary", ExampleMatcher.GenericPropertyMatcher::contains);
        val example = Example.of(employee,exampleMatcher);
        return salaryApplicationRepository.findAll(example,pageable);
      }

    public SalaryApplication save(SalaryApplication employee){
        return salaryApplicationRepository.save(employee);
    }

    public void deleteById(String id){
        salaryApplicationRepository.deleteById(id);
    }

    public SalaryDataPrediction getPrediction(int years) {
        val all = salaryRepository.findAll();
        return new SalaryDataPrediction(years, all);
    }
}
