package com.prj.serivce;

import com.prj.dto.SalaryApplication;
import com.prj.dto.SalaryData;
import com.prj.untils.SalaryDataPrediction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface SalaryService {

    Page<SalaryApplication> findAll(SalaryApplication employee, Pageable pageable);
    Page<SalaryApplication> findAll(Pageable pageable);

    public SalaryApplication save(SalaryApplication employee);

    public void deleteById(String id);

    public SalaryDataPrediction getPrediction(int years);
}
