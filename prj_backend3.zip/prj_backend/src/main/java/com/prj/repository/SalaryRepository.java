package com.prj.repository;

import com.prj.dto.EmployeeKpi;
import com.prj.dto.SalaryData;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

@Repository
public interface SalaryRepository extends JpaRepositoryImplementation<SalaryData,String> {
}
