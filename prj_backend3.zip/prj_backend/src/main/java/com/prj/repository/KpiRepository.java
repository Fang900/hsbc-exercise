package com.prj.repository;

import com.prj.dto.EmployeeKpi;
import com.prj.dto.SalaryApplication;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

@Repository
public interface KpiRepository extends JpaRepositoryImplementation<EmployeeKpi,String> {
}
