package com.prj.repository;

import com.prj.dto.Employee;
import com.prj.dto.SalaryApplication;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

@Repository
public interface SalaryApplicationRepository extends JpaRepositoryImplementation<SalaryApplication,String> {
}
